package com.ken.servlet.UserLogin;

import com.alibaba.fastjson.JSONArray;
import com.ken.pojo.SmbmsProvider;
import com.ken.pojo.SmbmsUser;
import com.ken.service.Provider.ProviderServiceImpl;
import com.ken.util.Constants;
import com.ken.util.PageSupport;
import com.mysql.cj.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class ProviderServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        if(!StringUtils.isNullOrEmpty(method) && "query".equals(method)) this.Query(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "add".equals(method)) this.Add(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "pcexist".equals(method)) this.Pcexist(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "view".equals(method)) this.View(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "modify".equals(method)) this.Modify(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "modifyexe".equals(method)) this.Modifyexe(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "delprovider".equals(method)) this.Delprovider(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    //根据条件查询供应商信息
    public void Query(HttpServletRequest req, HttpServletResponse resp){
        String queryProCode = req.getParameter("queryProCode");//供应商编码
        String queryProName = req.getParameter("queryProName");//供应商名称
        String pageIndex = req.getParameter("pageIndex");//当前页面

        int currentPageNo=1;
        if (!StringUtils.isNullOrEmpty(pageIndex)){
            currentPageNo = Integer.parseInt(pageIndex);
        }
        if(StringUtils.isNullOrEmpty(queryProCode)) queryProCode="";
        if(StringUtils.isNullOrEmpty(queryProName)) queryProName="";

        ProviderServiceImpl providerService = new ProviderServiceImpl();
        int totalCount = providerService.GetProviderCount(queryProCode, queryProName);
        PageSupport pageSupport = new PageSupport();
        pageSupport.setPageSize(Constants.PAGE_SIZE);
        pageSupport.setTotalCount(totalCount);
        pageSupport.setCurrentPageNo(currentPageNo);
        int totalPageCount = pageSupport.getTotalPageCount();

        if(currentPageNo<0){
            currentPageNo=1;
        }else if (currentPageNo>totalPageCount){
            currentPageNo = totalPageCount;
        }

        List<SmbmsProvider> providerList = providerService.GetProviderList(queryProCode, queryProName, currentPageNo, Constants.PAGE_SIZE);

        req.setAttribute("providerList",providerList);
        req.setAttribute("totalCount",totalCount);
        req.setAttribute("currentPageNo",currentPageNo);
        req.setAttribute("totalPageCount",totalPageCount);
        req.setAttribute("queryProCode",queryProCode);
        req.setAttribute("queryProName",queryProName);

        try {
            req.getRequestDispatcher("providerlist.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //添加供应商
    public void Add(HttpServletRequest req, HttpServletResponse resp){
        String proCode = req.getParameter("proCode");
        String proName = req.getParameter("proName");
        String proContact = req.getParameter("proContact");
        String proPhone = req.getParameter("proPhone");
        String proAddress = req.getParameter("proAddress");
        String proFax = req.getParameter("proFax");
        String proDesc = req.getParameter("proDesc");

        SmbmsProvider _Provider = new SmbmsProvider();
        _Provider.setproCode(proCode);
        _Provider.setproName(proName);
        _Provider.setproContact(proContact);
        _Provider.setproPhone(proPhone);
        _Provider.setproAddress(proAddress);
        _Provider.setproFax(proFax);
        _Provider.setproDesc(proDesc);


        _Provider.setCreatedby((long)((SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION)).getId());
        _Provider.setcreationDate(new Date());

        ProviderServiceImpl providerService = new ProviderServiceImpl();
        if (providerService.AddProvider(_Provider)){
            try {
                resp.sendRedirect(req.getContextPath() + "/jsp/provider.do?method=query");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            try {
                req.getRequestDispatcher("provideradd.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //查看供应商编号是否存在
    public void Pcexist(HttpServletRequest req, HttpServletResponse resp){
        String proCode = req.getParameter("proCode");
        HashMap<String, String> kvproCode = new HashMap<>();

        if (StringUtils.isNullOrEmpty(proCode)){
            kvproCode.put("proCode","empty");
        }else {
            ProviderServiceImpl providerService = new ProviderServiceImpl();
            if(providerService.ProviderCodeIsExist(proCode)){
                kvproCode.put("proCode","exist");
            }else{
                kvproCode.put("proCode","NOexist");
            }
        }

        resp.setContentType("application/json");
        try {
            resp.getWriter().write(JSONArray.toJSONString(kvproCode));
            resp.getWriter().flush();
            resp.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //展示供应商信息
    public void View(HttpServletRequest req, HttpServletResponse resp){
        String proid = req.getParameter("proid");
        System.out.println("进入View，proid=" + proid);
        if(StringUtils.isNullOrEmpty(proid)){
            try {
                resp.sendRedirect(req.getContextPath() + "/error.jsp");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            ProviderServiceImpl providerService = new ProviderServiceImpl();
            SmbmsProvider provider = providerService.GetProviderByID(Integer.parseInt(proid));
            req.setAttribute("provider",provider);
            try {
                req.getRequestDispatcher("providerview.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //修改供应商信息页面
    public void Modify(HttpServletRequest req, HttpServletResponse resp){
        String proid = req.getParameter("proid");
        if(!StringUtils.isNullOrEmpty(proid)){
            ProviderServiceImpl providerService = new ProviderServiceImpl();
            SmbmsProvider provider = providerService.GetProviderByID(Integer.parseInt(proid));
            req.setAttribute("provider",provider);
        }
        try {
            req.getRequestDispatcher("providermodify.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //修改供应商信息
    public void Modifyexe(HttpServletRequest req, HttpServletResponse resp){
        String providerid = req.getParameter("providerid");
        String proCode = req.getParameter("proCode");
        String proName = req.getParameter("proName");
        String proContact = req.getParameter("proContact");
        String proPhone = req.getParameter("proPhone");
        String proAddress = req.getParameter("proAddress");
        String proFax = req.getParameter("proFax");
        String proDesc = req.getParameter("proDesc");

        if (StringUtils.isNullOrEmpty(providerid)){
            try {
                resp.sendRedirect(req.getContextPath() + "/error.jsp");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            SmbmsProvider provider = new SmbmsProvider();
            provider.setId(Long.valueOf(providerid));
            provider.setproCode(proCode);
            provider.setproName(proName);
            provider.setproContact(proContact);
            provider.setproPhone(proPhone);
            provider.setproAddress(proAddress);
            provider.setproFax(proFax);
            provider.setproDesc(proDesc);

            provider.setModifyby((long) ((SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION)).getId());
            provider.setModifydate(new Date());

            ProviderServiceImpl providerService = new ProviderServiceImpl();
            if (providerService.UpdateProvider(provider)){
                try {
                    resp.sendRedirect(req.getContextPath() + "/jsp/provider.do?method=query");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }else {
                try {
                    resp.sendRedirect(req.getContextPath() + "/error.jsp");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //删除供应商信息
    public void Delprovider(HttpServletRequest req, HttpServletResponse resp){
        String proid = req.getParameter("proid");
        HashMap<String, String> kvMessage = new HashMap<>();
        if (StringUtils.isNullOrEmpty(proid)){
            kvMessage.put("delResult","notexist");
        }else{
            ProviderServiceImpl providerService = new ProviderServiceImpl();
            int count = providerService.ProviderIsNoPayment(Integer.parseInt(proid));
            if(count>0){
                kvMessage.put("delResult", String.valueOf(count));
            }else{
                if(providerService.DeleteProvider(Integer.parseInt(proid))){
                    kvMessage.put("delResult","true");
                }else{
                    kvMessage.put("delResult","false");
                }
            }
        }

        resp.setContentType("application/json");
        try {
            resp.getWriter().write(JSONArray.toJSONString(kvMessage));
            resp.getWriter().flush();
            resp.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
