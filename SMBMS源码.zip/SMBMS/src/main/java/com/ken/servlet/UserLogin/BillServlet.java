package com.ken.servlet.UserLogin;

import com.alibaba.fastjson.JSONArray;
import com.ken.pojo.SmbmsBill;
import com.ken.pojo.SmbmsProvider;
import com.ken.pojo.SmbmsUser;
import com.ken.service.Bill.BillServiceImpl;
import com.ken.service.Provider.ProviderServiceImpl;
import com.ken.util.Constants;
import com.ken.util.PageSupport;
import com.mysql.cj.util.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class BillServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        if(!StringUtils.isNullOrEmpty(method) && "query".equals(method)) this.Query(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "getproviderlist".equals(method)) this.GetProviderList(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "add".equals(method)) this.Add(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "bcexist".equals(method)) this.Bcexist(req, resp);
        if(!StringUtils.isNullOrEmpty(method) && "view".equals(method)) this.ViewBill(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "modify".equals(method)) this.Modify(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "modifysave".equals(method)) this.ModifySave(req,resp);
        if(!StringUtils.isNullOrEmpty(method) && "delbill".equals(method)) this.Delbill(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    //查询返回列表数据
    public void Query(HttpServletRequest req, HttpServletResponse resp){
        String queryProductName = req.getParameter("queryProductName");//商品名称
        String reqProviderId = req.getParameter("queryProviderId");//供应商id
        String reqIsPayment = req.getParameter("queryIsPayment");//是否付款
        String pageIndex = req.getParameter("pageIndex");//当前展现的页面

        int providerId = 0;
        int isPayment = 0;
        int currentPageNO=1;

        if(StringUtils.isNullOrEmpty(queryProductName)){
            queryProductName="";
        }
        if(!StringUtils.isNullOrEmpty(reqProviderId)) providerId = Integer.parseInt(reqProviderId);
        if(!StringUtils.isNullOrEmpty(reqIsPayment)) isPayment = Integer.parseInt(reqIsPayment);
        if(!StringUtils.isNullOrEmpty(pageIndex)) currentPageNO = Integer.parseInt(pageIndex);

        BillServiceImpl billService = new BillServiceImpl();
        int totalCount = billService.GetBillCount(queryProductName, providerId, isPayment);

        PageSupport pageSupport = new PageSupport();
        pageSupport.setPageSize(Constants.PAGE_SIZE);
        pageSupport.setCurrentPageNo(currentPageNO);

        pageSupport.setTotalCount(totalCount);



        int totalPageCount = pageSupport.getTotalPageCount();//最后一页
        if(currentPageNO < 1){
            currentPageNO = 1;
        }else if(currentPageNO > totalPageCount){
            currentPageNO = totalPageCount;
        }

        //商品列表
        List<SmbmsBill> smbmsBills = billService.GetBillList(queryProductName, providerId, isPayment, currentPageNO, Constants.PAGE_SIZE);
        req.setAttribute("billList",smbmsBills);

        //商户列表
        ProviderServiceImpl providerService = new ProviderServiceImpl();
        List<SmbmsProvider> providerList = providerService.GetProviderList();
        req.setAttribute("providerList",providerList);

        req.setAttribute("totalCount",totalCount);
        req.setAttribute("currentPageNo",currentPageNO);
        req.setAttribute("totalPageCount",totalPageCount);
        req.setAttribute("queryProductName",queryProductName);
        req.setAttribute("queryProviderId",providerId);
        req.setAttribute("queryIsPayment",isPayment);


        try {
            req.getRequestDispatcher("billlist.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //商户列表json
    public void GetProviderList(HttpServletRequest req, HttpServletResponse resp){
        ProviderServiceImpl providerService = new ProviderServiceImpl();
        List<SmbmsProvider> providerList = providerService.GetProviderList();

        resp.setContentType("application/json");
        PrintWriter writer=null;
        try {
            writer = resp.getWriter();
            writer.write(JSONArray.toJSONString(providerList));

        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            writer.flush();
            writer.close();
        }
    }

    //添加商品信息
    public void Add(HttpServletRequest req, HttpServletResponse resp){
        String billCode = req.getParameter("billCode");
        String productName = req.getParameter("productName");
        String productDesc = req.getParameter("productDesc");
        String productUnit = req.getParameter("productUnit");
        String productCount = req.getParameter("productCount");
        String totalPrice = req.getParameter("totalPrice");
        String providerId = req.getParameter("providerId");
        String isPayment = req.getParameter("isPayment");

        SmbmsBill _smbmsBill = new SmbmsBill();
        _smbmsBill.setbillCode(billCode);
        _smbmsBill.setproductName(productName);
        _smbmsBill.setproductDesc(productDesc);
        _smbmsBill.setproductUnit(productUnit);
        _smbmsBill.setproductCount(Double.valueOf(productCount));
        _smbmsBill.settotalPrice(Double.valueOf(totalPrice));
        _smbmsBill.setproviderId(Long.valueOf(providerId));
        _smbmsBill.setisPayment(Integer.valueOf(isPayment));

        _smbmsBill.setcreationDate(new Date());
        _smbmsBill.setCreatedby((long) ((SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION)).getId());

        BillServiceImpl billService = new BillServiceImpl();

        if(billService.AddBill(_smbmsBill)){

            try {
                resp.sendRedirect(req.getContextPath()+"/jsp/bill.do?method=query");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            try {
                req.getRequestDispatcher("billadd.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //核验订单编码是否存在
    public void Bcexist(HttpServletRequest req, HttpServletResponse resp){
        String billCode = req.getParameter("billCode");
        HashMap<String, String> kvBcexist = new HashMap<>();

        if(StringUtils.isNullOrEmpty(billCode)){
            kvBcexist.put("billCode","empty");
        }else {
            BillServiceImpl billService = new BillServiceImpl();
            if(billService.BillCodeIsExist(billCode)){
                kvBcexist.put("billCode","exist");
            }else {
                kvBcexist.put("billCode","NOexist");
            }
        }
        resp.setContentType("application/json");
        PrintWriter writer=null;
        try {
            writer = resp.getWriter();
            writer.write(JSONArray.toJSONString(kvBcexist));
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            writer.flush();
            writer.close();
        }

    }

    //展现订单详情
    public void ViewBill(HttpServletRequest req, HttpServletResponse resp){
        String billid = req.getParameter("billid");
        if (!StringUtils.isNullOrEmpty(billid)){
            BillServiceImpl billService = new BillServiceImpl();
            SmbmsBill smbmsBill = billService.GetBillByID(billid);

            req.setAttribute("bill",smbmsBill);
            try {
                req.getRequestDispatcher("billview.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //修改订单信息页面展示
    public void Modify(HttpServletRequest req, HttpServletResponse resp){
        String billid = req.getParameter("billid");
        BillServiceImpl billService = new BillServiceImpl();
        SmbmsBill smbmsBill = billService.GetBillByID(billid);
        req.setAttribute("bill",smbmsBill);

        try {
            req.getRequestDispatcher("billmodify.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //提交订单修改信息
    public void ModifySave(HttpServletRequest req, HttpServletResponse resp){
        String billCode = req.getParameter("billCode");//订单编码
        String productName = req.getParameter("productName");//商品名称
        String productDesc = req.getParameter("productDesc");//商品描述
        String productUnit = req.getParameter("productUnit");//商品单位
        String productCount = req.getParameter("productCount");//商品数量
        String totalPrice = req.getParameter("totalPrice");//总金额
        String providerId = req.getParameter("providerId");//供应商
        String isPayment = req.getParameter("isPayment");//是否付款
        String id = req.getParameter("id");

        SmbmsBill _bill = new SmbmsBill();
        if (StringUtils.isNullOrEmpty(billCode)){
            try {
                resp.sendRedirect(req.getContextPath() + "/jsp/error.jsp");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            _bill.setbillCode(billCode);
        }
        _bill.setproductName(productName);
        _bill.setproductDesc(productDesc);
        _bill.setproductUnit(productUnit);
        _bill.setproductCount(Double.valueOf(productCount));
        _bill.settotalPrice(Double.valueOf(totalPrice));
        _bill.setproviderId(Long.valueOf(providerId));
        _bill.setisPayment(Integer.valueOf(isPayment));
        _bill.setId(Long.valueOf(id));

        _bill.setModifyby((long) ((SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION)).getId());
        _bill.setModifydate(new Date());

        BillServiceImpl billService = new BillServiceImpl();

        if(billService.UpdateBill(_bill)){

            try {
                resp.sendRedirect(req.getContextPath() + "/jsp/bill.do?method=query");
            } catch (IOException e) {
                e.printStackTrace();
            }

        }else {
            try {
                resp.sendRedirect(req.getContextPath() + "/jsp/error.jsp");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //删除订单信息
    public void Delbill(HttpServletRequest req, HttpServletResponse resp){
        String billid = req.getParameter("billid");

        HashMap<String, String> kvDelbill = new HashMap<String, String>();

        if(StringUtils.isNullOrEmpty(billid)){
            kvDelbill.put("delResult","notexist");
        }else {
            BillServiceImpl billService = new BillServiceImpl();
            SmbmsBill smbmsBill = billService.GetBillByID(billid);
            if (smbmsBill.getisPayment().equals(1)){
                kvDelbill.put("delResult","noPayment");
            }else {
                if(billService.DeleteBill(billid)){
                    kvDelbill.put("delResult","true");
                }else {
                    kvDelbill.put("delResult","false");
                }
            }
        }

        resp.setContentType("application/json");
        try {
            resp.getWriter().write(JSONArray.toJSONString(kvDelbill));
            resp.getWriter().flush();
            resp.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
