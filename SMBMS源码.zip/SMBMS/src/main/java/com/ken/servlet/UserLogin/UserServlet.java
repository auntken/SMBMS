package com.ken.servlet.UserLogin;

import com.alibaba.fastjson.JSONArray;
import com.ken.pojo.SmbmsRole;
import com.ken.pojo.SmbmsUser;
import com.ken.service.role.RoleServiceImpl;
import com.ken.service.user.UserService;
import com.ken.service.user.UserServiceImpl;
import com.ken.util.Constants;
import com.ken.util.PageSupport;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.xdevapi.JsonParser;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.SimpleTimeZone;

public class UserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String method = req.getParameter("method");
        if(method!=null && "savepwd".equals(method)) this.UpdatePassword(req,resp);
        if(method!=null && method.equals("pwdmodify")) this.OldPasswordVerify(req,resp);
        if(method!=null && method.equals("query")) this.Query(req,resp);
        if(method!=null && method.equals("add")) this.AddUser(req,resp);
        if(method!=null && "getrolelist".equals(method)) this.GetRoleList(req,resp);
        if(method!=null && "ucexist".equals(method)) this.UserCodeIsExist(req,resp);
        if(method!=null && "view".equals(method)) this.ViewUser(req,resp);
        if(method!=null && "modify".equals(method)) this.UserModify(req, resp);
        if(method!=null && "modifyexe".equals(method)) this.UserModifyexe(req, resp);
        if(method!=null && "deluser".equals(method)) this.DelectUser(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }


    //x修改密码
    public void UpdatePassword(HttpServletRequest req, HttpServletResponse resp){
        System.out.println("进入UpdatePassword");
        Object user = req.getSession().getAttribute(Constants.USER_SESSION);
        String newPassword = req.getParameter("newpassword");
        boolean flag=false;

        if (user!=null && !StringUtils.isNullOrEmpty(newPassword)){
            System.out.println("进入判断");
            UserServiceImpl userService = new UserServiceImpl();
            flag = userService.PasswordChange(((SmbmsUser) user).getId(), newPassword);
            if(flag){
                req.getSession().setAttribute(Constants.MESSAGE,"修改密码成功，请退出重新登录");
                req.getSession().removeAttribute(Constants.USER_SESSION);
            }else {
                req.getSession().setAttribute(Constants.MESSAGE,"修改密码失败");
            }
        }else{
            req.getSession().setAttribute(Constants.MESSAGE,"密码有问题");
        }
        try {
            req.getRequestDispatcher("pwdmodify.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //验证旧密码
    public void OldPasswordVerify(HttpServletRequest req, HttpServletResponse resp){
        String oldpassword = req.getParameter("oldpassword");
        Object user = req.getSession().getAttribute(Constants.USER_SESSION);
        HashMap<String, String> resultMap = new HashMap<>();

        if(user == null){
            resultMap.put("result","sessionerror");
        }else if(StringUtils.isNullOrEmpty(oldpassword)){
            resultMap.put("result","error");
        }else{
            if(((SmbmsUser)user).getUserpassword().equals(oldpassword)){
                resultMap.put("result","true");
            }else {
                resultMap.put("result","false");
            }
        }


        try {
            resp.setContentType("application/json");
            PrintWriter writer = resp.getWriter();
            writer.write(JSONArray.toJSONString(resultMap));
            writer.flush();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //响应展示用户列表
    public void Query(HttpServletRequest req, HttpServletResponse resp){
        String queryname = req.getParameter("queryname");//用户名
        String queryUserRoleTemp = req.getParameter("queryUserRole");//用户权限副本
        String pageIndex = req.getParameter("pageIndex");//当前页面

        int queryUserRole = 0;//用户权限
        int currentPageNo=1;//当前页面

        if(StringUtils.isNullOrEmpty(queryname)){
            queryname="";
        }
        if(queryUserRoleTemp!=null && queryUserRoleTemp!=""){
            queryUserRole = Integer.parseInt(queryUserRoleTemp);
        }
        if(pageIndex!=null){
            currentPageNo = Integer.parseInt(pageIndex);
        }

        UserServiceImpl userService = new UserServiceImpl();
        int totalCount = userService.GetUserCount(queryname,queryUserRole);//根据条件得到用户总数

        PageSupport pageSupport = new PageSupport();
        pageSupport.setPageSize(Constants.PAGE_SIZE);
        pageSupport.setCurrentPageNo(currentPageNo);
        pageSupport.setTotalCount(totalCount);

        int totalPageCount = pageSupport.getTotalPageCount();//最后一页

        if(currentPageNo<1){
            currentPageNo=1;
        }else if(currentPageNo>totalPageCount){
            currentPageNo = totalPageCount;
        }

        //获取用户列表
        List<SmbmsUser> userList = userService.GetUserList(queryname, queryUserRole, currentPageNo, Constants.PAGE_SIZE);

        req.setAttribute("userList",userList);
        //权限列表
        RoleServiceImpl roleService = new RoleServiceImpl();
        List<SmbmsRole> smbmsRoles = roleService.GetRoleList();


        req.setAttribute("roleList",smbmsRoles);

        req.setAttribute("totalPageCount",totalPageCount);
        req.setAttribute("totalCount",totalCount);
        req.setAttribute("currentPageNo",currentPageNo);
        req.setAttribute("queryUserName",queryname);
        req.setAttribute("queryUserRole",queryUserRole);

        try {
            req.getRequestDispatcher("userlist.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //添加用户
    public void AddUser(HttpServletRequest req, HttpServletResponse resp){
        String userCode = req.getParameter("userCode");
        String userName = req.getParameter("userName");
        String userPassword = req.getParameter("userPassword");
        Integer gender = Integer.valueOf(req.getParameter("gender"));
        String birthday = req.getParameter("birthday");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        String userRole = req.getParameter("userRole");

        SmbmsUser _smbmsUser = new SmbmsUser();
        _smbmsUser.setuserCode(userCode);
        _smbmsUser.setuserName(userName);
        _smbmsUser.setUserpassword(userPassword);
        _smbmsUser.setGender(gender);
        try {
            _smbmsUser.setBirthday(new SimpleDateFormat("yyyy-MM-dd").parse(birthday));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        _smbmsUser.setPhone(phone);
        _smbmsUser.setAddress(address);
        _smbmsUser.setuserRole(Long.valueOf(userRole));
        _smbmsUser.setCreationdate(new Date());
        SmbmsUser User = (SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION);
        _smbmsUser.setCreatedby((long) User.getId());

        UserServiceImpl userService = new UserServiceImpl();

        //System.out.println(_smbmsUser.getuserName());

        if(userService.AddUser(_smbmsUser)){
            try {
                resp.sendRedirect(req.getContextPath()+"/jsp/user.do?method=query");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else {
            try {
                req.getRequestDispatcher("useradd.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //获取用户列表
    public void GetRoleList(HttpServletRequest req, HttpServletResponse resp){
        RoleServiceImpl roleService = new RoleServiceImpl();
        List<SmbmsRole> smbmsRoles = roleService.GetRoleList();

        resp.setContentType("appliction/json");
        PrintWriter writer = null;
        try {
            writer = resp.getWriter();
            writer.write(JSONArray.toJSONString(smbmsRoles));
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            writer.close();
        }

    }

    //用户是否存在
    public void UserCodeIsExist(HttpServletRequest req, HttpServletResponse resp){
        String userCode = req.getParameter("userCode");
        HashMap<String, String> KVuserCode = new HashMap<String, String>();

        if (StringUtils.isNullOrEmpty(userCode)){
            KVuserCode.put("userCode","empty");
        }else {
            UserServiceImpl userService = new UserServiceImpl();
            if(userService.IsUserExist(userCode)){
                KVuserCode.put("userCode","exist");
            }else{
                KVuserCode.put("userCode","ok");
            }
        }

        resp.setContentType("application/json");
        try {
            resp.getWriter().write(JSONArray.toJSONString(KVuserCode));
            resp.getWriter().flush();
            resp.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //展示用户信息
    public void ViewUser(HttpServletRequest req, HttpServletResponse resp){

        String uid = req.getParameter("uid");

        if (!StringUtils.isNullOrEmpty(uid)){
            UserServiceImpl userService = new UserServiceImpl();
            SmbmsUser smbmsUser = userService.GetUserById(uid);
            req.setAttribute("user",smbmsUser);
            try {
                req.getRequestDispatcher("userview.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    //用户修改转跳
    public void UserModify(HttpServletRequest req, HttpServletResponse resp){
        String uid = req.getParameter("uid");
        if (!StringUtils.isNullOrEmpty(uid)){
            UserServiceImpl userService = new UserServiceImpl();
            SmbmsUser smbmsUser = userService.GetUserById(uid);

            req.setAttribute("user",smbmsUser);
        }
        try {
            req.getRequestDispatcher("usermodify.jsp").forward(req,resp);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //用户修改页面
    public void UserModifyexe(HttpServletRequest req, HttpServletResponse resp){
        String userName = req.getParameter("userName");
        String gender = req.getParameter("gender");
        String birthday = req.getParameter("birthday");
        String phone = req.getParameter("phone");
        String address = req.getParameter("address");
        String userRole = req.getParameter("userRole");
        String uid = req.getParameter("uid");

        SmbmsUser smbmsUser = new SmbmsUser();
        smbmsUser.setuserName(userName);
        smbmsUser.setGender(Integer.valueOf(gender));
        try {
            smbmsUser.setBirthday(new SimpleDateFormat("yyyy-MM-dd").parse(birthday));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        smbmsUser.setPhone(phone);
        smbmsUser.setAddress(address);
        smbmsUser.setuserRole(Long.valueOf(userRole));
        smbmsUser.setId(Integer.parseInt(uid));

        smbmsUser.setModifyby((long) ((SmbmsUser)req.getSession().getAttribute(Constants.USER_SESSION)).getId());
        smbmsUser.setModifydate(new Date());


        UserServiceImpl userService = new UserServiceImpl();
        boolean b = userService.UpdateUser(smbmsUser);
        if(b){
            try {
                resp.sendRedirect(req.getContextPath() + "/jsp/user.do?method=query");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }else{
            try {
                req.getRequestDispatcher("usermodify.jsp").forward(req,resp);
            } catch (ServletException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    //删除用户信息
    public void DelectUser(HttpServletRequest req, HttpServletResponse resp){
        String uid = req.getParameter("uid");//删除用户id
        int deleteID  = 0;
        deleteID = Integer.parseInt(uid);
        Long loginUserRole = ((SmbmsUser) req.getSession().getAttribute(Constants.USER_SESSION)).getuserRole();//当前登陆权限
        int loginUserID = ((SmbmsUser) req.getSession().getAttribute(Constants.USER_SESSION)).getId();//当前登陆id

        UserServiceImpl userService = new UserServiceImpl();
        SmbmsUser deleteUser = userService.GetUserById(uid);

        Long deleteUserRole = deleteUser.getuserRole();


        HashMap<String, String> kvDeluserData = new HashMap<>();

        if (loginUserRole >= deleteUserRole){
            //System.out.println("进入权限判断");
            kvDeluserData.put("delResult","cannotabc");


        } else if (loginUserID == deleteID){
            //System.out.println("进入登陆id判断");
            kvDeluserData.put("delResult","cannotdel");
        } else if(deleteID==0){
           // System.out.println("进入id为空判断");
            kvDeluserData.put("delResult","notexist");
        }else {
           // System.out.println("进入删除判断" + String.valueOf(deleteID));
            boolean flag = userService.DeleteUser(String.valueOf(deleteID));
            if(flag){
                kvDeluserData.put("delResult","true");
            }else {
                kvDeluserData.put("delResult","false");
            }
        }

        resp.setContentType("application/json");

        try {
            resp.getWriter().write(JSONArray.toJSONString(kvDeluserData));
            resp.getWriter().flush();
            resp.getWriter().close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
