package com.ken.service.user;

import com.ken.pojo.SmbmsUser;

import java.sql.Connection;
import java.util.List;

public interface UserService {
    //登陆的账号密码获取数据库里面的数据生成实体
    public SmbmsUser login(String usercode,String password);

    //修改密码
    public boolean PasswordChange(int id,String Password);

    //根据用户名和权限查询用户数量
    public int GetUserCount(String userName,int userRole);

    //根据条件查用户列表
    public List<SmbmsUser> GetUserList(String queryUserName ,int queryUserRole,int currentPage,int pageSize);

    //添加用户
    public boolean AddUser(SmbmsUser user);

    //查找账号名是否存在
    public boolean IsUserExist(String userCode);

    //根据id查用户信息
    public SmbmsUser GetUserById(String id);

    //修改用户信息
    public boolean UpdateUser(SmbmsUser user);

    //删除用户信息
    public boolean DeleteUser(String id);
}
