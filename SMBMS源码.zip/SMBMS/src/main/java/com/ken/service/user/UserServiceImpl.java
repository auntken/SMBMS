package com.ken.service.user;

import com.ken.dao.BaseDao;
import com.ken.dao.user.UserDaoImpl;
import com.ken.pojo.SmbmsUser;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserServiceImpl implements UserService{
    private UserDaoImpl userDao=null;
    public UserServiceImpl(){
      userDao  = new UserDaoImpl();
    }

    //登陆的账号密码获取数据库里面的数据生成实体
    @Override
    public SmbmsUser login(String usercode, String password) {
        Connection connection=null;
        SmbmsUser smbmsUser=null;
        try {
            connection = BaseDao.GetConnection();
            smbmsUser = userDao.GetLoginUser(connection,usercode);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            BaseDao.CloseResource(connection,null,null);
        }
        return smbmsUser;
    }

    //用户修改密码
    @Override
    public boolean PasswordChange(int id, String Password) {
        Connection connection = null;
        boolean flag =false;
        try {
            connection = BaseDao.GetConnection();
            flag = userDao.GetPasswordChangeResult(connection,id,Password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return flag;
    }


    @Override
    public int GetUserCount(String userName, int userRole) {
        Connection connection = null;
        int count=0;
        try {
            connection = BaseDao.GetConnection();
            count = userDao.GetUserCount(connection, userName, userRole);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return count;
    }

    //根据条件查用户列表
    @Override
    public List<SmbmsUser> GetUserList(String queryUserName, int queryUserRole, int currentPage, int pageSize) {
        Connection connection=null;
        List<SmbmsUser> userList = new ArrayList<>();

        try {
            connection = BaseDao.GetConnection();
            userList = userDao.GetUserList(connection,queryUserName,queryUserRole,currentPage,pageSize);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return userList;
    }

    //添加用户
    @Override
    public boolean AddUser(SmbmsUser user) {
        boolean flag=false;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            connection.setAutoCommit(false);
            int i = userDao.AddUser(connection, user);
            connection.commit();
            flag = i>0;
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return flag;
    }


    //查找账号名是否存在
    public boolean IsUserExist(String userCode){
        SmbmsUser smbmsUser=null;
        Connection connection=null;

        try {
            connection = BaseDao.GetConnection();
            smbmsUser = userDao.GetLoginUser(connection,userCode);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return !(smbmsUser==null);
    }

    //根据id查用户信息
    public SmbmsUser GetUserById(String id){
        SmbmsUser smbmsUser=null;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            smbmsUser = userDao.GetUserById(connection,id);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return smbmsUser;
    }

    //修改用户信息
    @Override
    public boolean UpdateUser(SmbmsUser user) {
        boolean flag = false;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            connection.setAutoCommit(false);
            flag = userDao.UpdateUser(connection, user);
            connection.commit();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    //删除用户信息
    @Override
    public boolean DeleteUser(String id) {
        boolean flag = false;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            connection.setAutoCommit(false);
            flag = userDao.DelectUser(connection,id);
            connection.commit();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return flag;
    }

    @Test
    public void test(){
//        UserServiceImpl userService = new UserServiceImpl();
//        System.out.println(userService.DeleteUser("25"));

    }
}


