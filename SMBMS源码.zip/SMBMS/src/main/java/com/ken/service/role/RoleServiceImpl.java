package com.ken.service.role;

import com.ken.dao.BaseDao;
import com.ken.dao.Role.RoleDao;
import com.ken.dao.Role.RoleDaoImpl;
import com.ken.pojo.SmbmsRole;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoleServiceImpl implements RoleService {
    private RoleDao roleDao=null;

    public RoleServiceImpl(){
        roleDao = new RoleDaoImpl();
    }
    @Override
    public List<SmbmsRole> GetRoleList() {
        List<SmbmsRole> roleList = null;
        Connection connection =null;
        try {
            connection = BaseDao.GetConnection();
            roleList = roleDao.GetRoleList(connection);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return roleList;
    }

    @Test
    public void test(){
        RoleServiceImpl roleService = new RoleServiceImpl();
        List<SmbmsRole> smbmsRoles = roleService.GetRoleList();

        for (SmbmsRole role:
             smbmsRoles) {
            System.out.println(role.getroleName()+"-------------------" +role.getId());
        }
    }
}


