package com.ken.service.role;

import com.ken.pojo.SmbmsRole;

import java.util.List;

public interface RoleService {
    //获取角色列表
    public List<SmbmsRole> GetRoleList();
}
