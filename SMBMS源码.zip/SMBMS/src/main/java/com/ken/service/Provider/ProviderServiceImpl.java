package com.ken.service.Provider;

import com.ken.dao.BaseDao;
import com.ken.dao.Provider.ProviderDaoImpl;
import com.ken.pojo.SmbmsProvider;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProviderServiceImpl implements ProviderService {

    ProviderDaoImpl providerDao=null;

    public ProviderServiceImpl(){
        providerDao = new ProviderDaoImpl();
    }

    @Override
    public List<SmbmsProvider> GetProviderList() {
        Connection connection=null;
        List<SmbmsProvider> providerList=null;
        try {
            connection = BaseDao.GetConnection();
            providerList = providerDao.GetProviderList(connection);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return providerList;
    }


    //根据条件查询供应商信息
    public List<SmbmsProvider> GetProviderList(String proCode, String proName, int currentPageNow, int pageSize){
        List<SmbmsProvider> providerList = new ArrayList<>();
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            providerList = providerDao.GetProviderList(connection,proCode,proName,currentPageNow,pageSize);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return providerList;
    }

    //根据条件查询供应商数量
    @Override
    public int GetProviderCount(String proCode, String proName) {
        int result=0;
        Connection connection=null;
        try {
            connection  = BaseDao.GetConnection();
            result = providerDao.GetProviderCount(connection,proCode,proName);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }


        return result;
    }

    //添加供应商
    @Override
    public boolean AddProvider(SmbmsProvider provider) {
        boolean flag=false;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            connection.setAutoCommit(false);
            flag = providerDao.AddProvider(connection, provider);
            connection.commit();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return flag;
    }

    //查看供应商编码是否存在
    @Override
    public boolean ProviderCodeIsExist(String pcode) {
        boolean flag=false;
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            flag = providerDao.ProviderCodeIsExist(connection,pcode);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return flag;
    }

    //根据Id查信息
    @Override
    public SmbmsProvider GetProviderByID(int id) {
        SmbmsProvider provider = null;
        Connection connection = null;
        try {
            connection = BaseDao.GetConnection();
            provider = providerDao.GetProviderByID(connection,id);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return provider;
    }


    //修改供应商信息
    @Override
    public boolean UpdateProvider(SmbmsProvider provider) {
        boolean flag = false;
        Connection connection = null;
        try {
            connection = BaseDao.GetConnection();
            flag = providerDao.UpdateProvider(connection,provider);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return flag;
    }

    //删除供应商信息
    @Override
    public boolean DeleteProvider(int id) {
        boolean flag = false;
        Connection connection = null;
        try {
            connection = BaseDao.GetConnection();
            flag = providerDao.DeleteProvider(connection,id);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    //查询供应商是否有没付款订单
    @Override
    public int ProviderIsNoPayment(int id) {
        int count = 0;
        Connection connection = null;
        try {
            connection = BaseDao.GetConnection();
            count = providerDao.ProviderIsNoPayment(connection,id);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return count;
    }


    @Test
    public void Test(){
        ProviderServiceImpl providerService = new ProviderServiceImpl();
//        SmbmsProvider smbmsProvider = new SmbmsProvider();
//        smbmsProvider.setproCode("asdfgdgh");
//        smbmsProvider.setproName("测试");
//        smbmsProvider.setproContact("测试");
//        smbmsProvider.setproPhone("q897118352");
//        smbmsProvider.setproAddress("测试");
//        smbmsProvider.setproFax("测试");
//        smbmsProvider.setproDesc("测试");
//        smbmsProvider.setCreatedby(1l);
//        smbmsProvider.setcreationDate(new Date());
//        smbmsProvider.setModifyby(1l);
//        smbmsProvider.setModifydate(new Date());
//        smbmsProvider.setId(17l);
//        System.out.println(providerService.UpdateProvider(smbmsProvider));

    }
}
