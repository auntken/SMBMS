package com.ken.service.Bill;

import com.ken.dao.BaseDao;
import com.ken.dao.Bill.BillDao;
import com.ken.dao.Bill.BillDaoImpl;
import com.ken.pojo.SmbmsBill;
import org.junit.Test;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BillServiceImpl implements BillService {
    BillDao billDao=null;

    public BillServiceImpl(){
        billDao=new BillDaoImpl();
    }

    @Override//获取商品信息列表
    public List<SmbmsBill> GetBillList(String productName, int proid, int isPayment, int currentPageNo, int pageSize) {
        List<SmbmsBill> billList = new ArrayList<>();
        Connection connection=null;
        try {
            connection = BaseDao.GetConnection();
            billList = billDao.GetBillList(connection,productName,proid,isPayment,currentPageNo,pageSize);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return billList;
    }

    @Override//商品总数
    public int GetBillCount(String productName, int proid, int isPayment){
        Connection connection=null;
        int count=0;
        try {
            connection = BaseDao.GetConnection();
            count = billDao.GetBillCount(connection,productName,proid,isPayment);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return count;
    }

    @Override//添加商品信息
    public boolean AddBill(SmbmsBill bill) {
        boolean flag=false;
        Connection connection =null;
        try {
            connection = BaseDao.GetConnection();
            flag = billDao.AddBill(connection,bill);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return flag;
    }

    //核验订单编码是否存在
    public boolean BillCodeIsExist(String billCode){
        Connection connection = null;
        boolean flag = false;
        try {
            connection = BaseDao.GetConnection();
            flag = billDao.BillCodeIsExist(connection, billCode);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return  flag;
    }

    //根据id查订单信息
    @Override
    public SmbmsBill GetBillByID(String ID) {
        Connection connection = null;
        SmbmsBill smbmsBill=null;
        try {
            connection = BaseDao.GetConnection();
            smbmsBill = billDao.GetBillByID(connection,ID);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }

        return smbmsBill;
    }

    //修改订单信息
    @Override
    public boolean UpdateBill(SmbmsBill smbmsBill) {
        boolean flag=false;
        Connection connection = null;
        try {
            connection  = BaseDao.GetConnection();
            flag = billDao.UpdateBill(connection,smbmsBill);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    //删除订单信息
    public boolean DeleteBill(String id){
        boolean flag = false;
        Connection connection = null;
        try {
            connection = BaseDao.GetConnection();
            flag = billDao.DeleteBill(connection, id);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    @Test
    public void test(){
//        BillServiceImpl billService = new BillServiceImpl();
//        System.out.println( billService.DeleteBill("105"));
    }
}
