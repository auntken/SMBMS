package com.ken.pojo;

import java.util.Date;
import java.io.Serializable;

/**
 * (SmbmsProvider)实体类
 *
 * @author makejava
 * @since 2022-11-19 15:57:35
 */
public class SmbmsProvider implements Serializable {
    private static final long serialVersionUID = -80529370183475443L;
    /**
     * 主键ID
     */
    private Long id;
    /**
     * 供应商编码
     */
    private String proCode;
    /**
     * 供应商名称
     */
    private String proName;
    /**
     * 供应商详细描述
     */
    private String proDesc;
    /**
     * 供应商联系人
     */
    private String proContact;
    /**
     * 联系电话
     */
    private String proPhone;
    /**
     * 地址
     */
    private String proAddress;
    /**
     * 传真
     */
    private String proFax;
    /**
     * 创建者（userId）
     */
    private Long createdby;
    /**
     * 创建时间
     */
    private Date creationDate;
    /**
     * 更新时间
     */
    private Date modifydate;
    /**
     * 更新者（userId）
     */
    private Long modifyby;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getproCode() {
        return proCode;
    }

    public void setproCode(String proCode) {
        this.proCode = proCode;
    }

    public String getproName() {
        return proName;
    }

    public void setproName(String proName) {
        this.proName = proName;
    }

    public String getproDesc() {
        return proDesc;
    }

    public void setproDesc(String proDesc) {
        this.proDesc = proDesc;
    }

    public String getproContact() {
        return proContact;
    }

    public void setproContact(String proContact) {
        this.proContact = proContact;
    }

    public String getproPhone() {
        return proPhone;
    }

    public void setproPhone(String proPhone) {
        this.proPhone = proPhone;
    }

    public String getproAddress() {
        return proAddress;
    }

    public void setproAddress(String proAddress) {
        this.proAddress = proAddress;
    }

    public String getproFax() {
        return proFax;
    }

    public void setproFax(String proFax) {
        this.proFax = proFax;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getcreationDate() {
        return creationDate;
    }

    public void setcreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Long getModifyby() {
        return modifyby;
    }

    public void setModifyby(Long modifyby) {
        this.modifyby = modifyby;
    }

}

