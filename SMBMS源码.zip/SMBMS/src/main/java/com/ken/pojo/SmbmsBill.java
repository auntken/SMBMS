package com.ken.pojo;

import java.util.Date;
import java.io.Serializable;

/**
 * (SmbmsBill)实体类
 *
 * @author makejava
 * @since 2022-11-19 15:56:32
 */
public class SmbmsBill implements Serializable {
    private static final long serialVersionUID = -71443409367438516L;
    /**
     * 主键ID
     */
    private Long id;
    /**
     * 账单编码
     */
    private String billCode;
    /**
     * 商品名称
     */
    private String productName;

    //供应商名称
    private String providerName;

    public String getproviderName() {
        return providerName;
    }

    public void setproviderName(String providerName) {
        this.providerName = providerName;
    }

    /**
     * 商品描述
     */
    private String productDesc;
    /**
     * 商品单位
     */
    private String productUnit;
    /**
     * 商品数量
     */
    private Double productCount;
    /**
     * 商品总额
     */
    private Double totalPrice;
    /**
     * 是否支付（1：未支付 2：已支付）
     */
    private Integer isPayment;
    /**
     * 创建者（userId）
     */
    private Long createdby;
    /**
     * 创建时间
     */
    private Date creationDate;
    /**
     * 更新者（userId）
     */
    private Long modifyby;
    /**
     * 更新时间
     */
    private Date modifydate;
    /**
     * 供应商ID
     */
    private Long providerId;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getbillCode() {
        return billCode;
    }

    public void setbillCode(String billCode) {
        this.billCode = billCode;
    }

    public String getproductName() {
        return productName;
    }

    public void setproductName(String productName) {
        this.productName = productName;
    }

    public String getproductDesc() {
        return productDesc;
    }

    public void setproductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getproductUnit() {
        return productUnit;
    }

    public void setproductUnit(String productUnit) {
        this.productUnit = productUnit;
    }

    public Double getproductCount() {
        return productCount;
    }

    public void setproductCount(Double productCount) {
        this.productCount = productCount;
    }

    public Double gettotalPrice() {
        return totalPrice;
    }

    public void settotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Integer getisPayment() {
        return isPayment;
    }

    public void setisPayment(Integer isPayment) {
        this.isPayment = isPayment;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getcreationDate() {
        return creationDate;
    }

    public void setcreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public Long getModifyby() {
        return modifyby;
    }

    public void setModifyby(Long modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

    public Long getproviderId() {
        return providerId;
    }

    public void setproviderId(Long providerId) {
        this.providerId = providerId;
    }

}

