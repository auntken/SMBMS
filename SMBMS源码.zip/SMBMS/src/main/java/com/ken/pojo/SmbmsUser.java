package com.ken.pojo;

import java.util.Date;
import java.io.Serializable;

/**
 * (SmbmsUser)实体类
 *
 * @author makejava
 * @since 2022-11-19 15:58:46
 */
public class SmbmsUser implements Serializable {
    private static final long serialVersionUID = -95071300782303704L;
    /**
     * 主键ID
     */
    private int id;
    /**
     * 用户编码
     */
    private String userCode;
    /**
     * 用户名称
     */
    private String userName;
    /**
     * 用户密码
     */
    private String userpassword;
    /**
     * 性别（1:女、 2:男）
     */
    private Integer gender;
    /**
     * 出生日期
     */
    private Date birthday;
    /**
     * 手机
     */
    private String phone;
    /**
     * 地址
     */
    private String address;
    /**
     * 用户角色（取自角色表-角色id）
     */
    private Long userRole;

    private int age;

    public int getage() {
        return age;
    }

    public void setage(int age) {
        this.age = age;
    }

    public String getuserRoleName() {
        return userRoleName;
    }

    public void setuserRoleName(String userRoleName) {
        this.userRoleName = userRoleName;
    }

    private String userRoleName;
    /**
     * 创建者（userId）
     */
    private Long createdby;
    /**
     * 创建时间
     */
    private Date creationdate;
    /**
     * 更新者（userId）
     */
    private Long modifyby;
    /**
     * 更新时间
     */
    private Date modifydate;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getuserCode() {
        return userCode;
    }

    public void setuserCode(String userCode) {
        this.userCode = userCode;
    }

    public String getuserName() {
        return userName;
    }

    public void setuserName(String userName) {
        this.userName = userName;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getuserRole() {
        return userRole;
    }

    public void setuserRole(Long userRole) {
        this.userRole = userRole;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(Date creationdate) {
        this.creationdate = creationdate;
    }

    public Long getModifyby() {
        return modifyby;
    }

    public void setModifyby(Long modifyby) {
        this.modifyby = modifyby;
    }

    public Date getModifydate() {
        return modifydate;
    }

    public void setModifydate(Date modifydate) {
        this.modifydate = modifydate;
    }

}

