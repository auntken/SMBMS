package com.ken.util;

public class Constants {
    public static final String USER_SESSION = "user_session";
    public static final String MESSAGE ="message";
    public static final int PAGE_SIZE = 5;
}
