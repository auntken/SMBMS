package com.ken.Filter;

import com.ken.pojo.SmbmsUser;
import com.ken.util.Constants;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class SysFilter implements Filter {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest HSRequest = (HttpServletRequest) servletRequest;
        HttpServletResponse HSResponse = (HttpServletResponse) servletResponse;

        SmbmsUser user = (SmbmsUser) HSRequest.getSession().getAttribute(Constants.USER_SESSION);

        if(user==null){
            HSResponse.sendRedirect(HSRequest.getContextPath()+"/error.jsp");
        }else {
            filterChain.doFilter(HSRequest,HSResponse);
        }
    }
}
