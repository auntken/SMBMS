package com.ken.dao.user;

import com.ken.pojo.SmbmsUser;

import java.sql.Connection;
import java.util.List;

public interface UserDao {
    //用户登录验证
    public SmbmsUser GetLoginUser(Connection connection,String usercode);

    //用户修改密码
    public boolean GetPasswordChangeResult(Connection connection,int id,String password);

    //根据用户名和权限查询用户数量
    public int GetUserCount(Connection connection,String username,int userRole);

    //获取用户列表
    public List<SmbmsUser> GetUserList(Connection connection,String username,int userRole,int currentPageNo, int pageSize);

    //添加用户
    public int AddUser(Connection connection,SmbmsUser user);

    //根据id查用户信息
    public SmbmsUser GetUserById(Connection connection,String id);

    //修改用户信息
    public boolean UpdateUser(Connection connection,SmbmsUser user);

    //删除用户信息
    public boolean DelectUser(Connection connection,String id);
}
