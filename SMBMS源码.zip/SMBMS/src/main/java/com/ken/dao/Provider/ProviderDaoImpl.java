package com.ken.dao.Provider;

import com.ken.dao.BaseDao;
import com.ken.pojo.SmbmsProvider;
import com.mysql.cj.util.StringUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProviderDaoImpl implements ProviderDao {
    @Override//获取供应商列表
    public List<SmbmsProvider> GetProviderList(Connection connection) {
        ArrayList<SmbmsProvider> smbmsProviders = new ArrayList<SmbmsProvider>();

        if(connection!=null){
            String sql = "SELECT * FROM smbms_lib.smbms_provider ";
            ResultSet resultSet =null;
            Object values[]={};
            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                while (resultSet.next()){
                    SmbmsProvider _smbmsProvider = new SmbmsProvider();
                    _smbmsProvider.setId((long) resultSet.getInt("id"));
                    _smbmsProvider.setproName(resultSet.getString("proName"));
                    smbmsProviders.add(_smbmsProvider);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }

        return smbmsProviders;
    }

    //根据条件查询供应商信息
    @Override
    public List<SmbmsProvider> GetProviderList(Connection connection, String proCode, String proName, int currentPageNow, int pageSize) {

        StringBuffer sql = new StringBuffer();
        ArrayList<Object> valuesTemp = new ArrayList<>();
        if (connection != null) {
            sql.append("SELECT * FROM smbms_lib.smbms_provider where 1=1 ");

            if (!StringUtils.isNullOrEmpty(proCode)){
                sql.append(" and proCode like ? ");
                valuesTemp.add("%" + proCode + "%");
            }
            if(!StringUtils.isNullOrEmpty(proName)){
                sql.append(" and proName like ? ");
                valuesTemp.add("%" + proName + "%");
            }

        }

        sql.append(" order by creationDate desc limit ?,? ");
        currentPageNow = (currentPageNow-1)*pageSize;
        valuesTemp.add(currentPageNow);
        valuesTemp.add(pageSize);

        Object values[] = valuesTemp.toArray();
        ResultSet resultSet=null;
        ArrayList<SmbmsProvider> ProviderList = new ArrayList<>();
        try {
            resultSet = BaseDao.ExecuteQuery(connection, String.valueOf(sql), values);
            while (resultSet.next()){
                SmbmsProvider _sp = new SmbmsProvider();
                _sp.setId(resultSet.getLong("id"));
                _sp.setproCode(resultSet.getString("proCode"));
                _sp.setproName(resultSet.getString("proName"));
                _sp.setproContact(resultSet.getString("proContact"));
                _sp.setproPhone(resultSet.getString("proPhone"));
                _sp.setproFax(resultSet.getString("proFax"));
                _sp.setcreationDate(resultSet.getDate("creationDate"));

                ProviderList.add(_sp);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(null,null,resultSet);
        }

        return ProviderList;
    }

    //根据条件查询供应商数量
    @Override
    public int GetProviderCount(Connection connection, String proCode, String proName) {
        StringBuffer sql = new StringBuffer();
        ArrayList<Object> valuesTemp = new ArrayList<>();
        int count=0;
        if (connection != null) {
            sql.append("SELECT count(id) as count  FROM smbms_lib.smbms_provider where 1=1 ");

            if (!StringUtils.isNullOrEmpty(proCode)){
                sql.append(" and proCode like ? ");
                valuesTemp.add("%" + proCode + "%");
            }
            if(!StringUtils.isNullOrEmpty(proName)){
                sql.append(" and proName like ? ");
                valuesTemp.add("%" + proName + "%");
            }

        }
        Object[] values = valuesTemp.toArray();
        ResultSet resultSet=null;
        try {
            resultSet = BaseDao.ExecuteQuery(connection, String.valueOf(sql), values);
            if(resultSet.next()) count = resultSet.getInt("count");
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(null,null,resultSet);
        }

        return count;
    }

    //添加供应商
    @Override
    public boolean AddProvider(Connection connection, SmbmsProvider provider) {
        boolean flag=false;
        if(connection!=null){
            String sql = "insert into smbms_provider(proCode,proName,proContact,proPhone,proAddress," +
                    "proFax,proDesc,createdBy,creationDate) values(?,?,?,?,?,?,?,?,?)";
            Object values[] = {provider.getproCode(),provider.getproName(),provider.getproContact(),
                    provider.getproPhone(),provider.getproAddress(),provider.getproFax(),provider.getproDesc(),
                    provider.getCreatedby(),provider.getcreationDate()};

            try {
                int i = BaseDao.ExecuteUpdate(connection, sql, values);
                flag=i>0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    //查看供应商编码是否存在
    @Override
    public boolean ProviderCodeIsExist(Connection connection, String pcode) {
        boolean flag=false;

        if (connection != null) {
            String sql = "SELECT * FROM smbms_lib.smbms_provider where proCode = ? ";
            Object values[] = {pcode};

            ResultSet resultSet=null;
            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                if (resultSet.next()) flag = true;
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return flag;
    }

    //根据Id查信息
    @Override
    public SmbmsProvider GetProviderByID(Connection connection, int id) {
        SmbmsProvider provider = null;
        if(connection!=null){
            String sql = "SELECT * FROM smbms_lib.smbms_provider where id = ? ";
            Object values[] = {id};
            ResultSet resultSet = null;
            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                if (resultSet.next()){
                    provider = new SmbmsProvider();
                    provider.setproCode(resultSet.getString("proCode"));
                    provider.setproName(resultSet.getString("proName"));
                    provider.setproContact(resultSet.getString("proContact"));
                    provider.setproPhone(resultSet.getString("proPhone"));
                    provider.setproFax(resultSet.getString("proFax"));
                    provider.setproDesc(resultSet.getString("proDesc"));
                    provider.setproAddress(resultSet.getString("proAddress"));
                    provider.setId(resultSet.getLong("id"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return provider;
    }

    //修改供应商信息
    @Override
    public boolean UpdateProvider(Connection connection, SmbmsProvider provider) {
        boolean flag = false;
        if (connection!=null){
            String sql = "update smbms_provider set proCode = ?,proName = ?,proContact = ?,proPhone = ?," +
                    "proAddress = ?,proFax = ?,proDesc = ?,modifyBy = ?,modifyDate = ?" +
                    " where id = ?";
            Object values[] = {provider.getproCode(),provider.getproName(),provider.getproContact(),provider.getproPhone(),
                    provider.getproAddress(),provider.getproFax(),provider.getproDesc(), provider.getModifyby(),
                    provider.getModifydate(),provider.getId()};
            try {
                int i = BaseDao.ExecuteUpdate(connection, sql, values);
                flag = i > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    //删除供应商信息
    @Override
    public boolean DeleteProvider(Connection connection, int id) {
        boolean flag = false;
        if (connection!=null){
            String sql = "delete from smbms_provider where id = ? ";
            Object values[] = {id};

            try {
                int i = BaseDao.ExecuteUpdate(connection, sql, values);
                flag = i > 0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return flag;
    }

    //查询供应商是否有没付款订单
    @Override
    public int ProviderIsNoPayment(Connection connection, int id) {
        int count = 0;
        if (connection!=null){
            String sql = "SELECT p.id,p.proName,b.isPayment FROM smbms_provider p, smbms_bill b " +
                    "where b.providerId = p.id and b.isPayment = 1 and p.id = ?";
            Object values[] = {id};
            ResultSet resultSet = null;
            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                while(resultSet.next()){
                    count++;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return count;
    }
}
