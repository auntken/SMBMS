package com.ken.dao.Role;

import com.ken.pojo.SmbmsRole;

import java.sql.Connection;
import java.util.List;

public interface RoleDao {
    public List<SmbmsRole> GetRoleList(Connection connection);
}
