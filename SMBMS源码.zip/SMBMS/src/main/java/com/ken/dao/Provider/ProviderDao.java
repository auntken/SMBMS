package com.ken.dao.Provider;

import com.ken.pojo.SmbmsProvider;

import java.sql.Connection;
import java.util.List;

public interface ProviderDao {

    //获取供应商列表
    public List<SmbmsProvider> GetProviderList(Connection connection);

    //根据条件查询供应商信息
    public List<SmbmsProvider> GetProviderList(Connection connection,String proCode,String proName,int currentPageNow, int pageSize);

    //根据条件查询供应商数量
    public int GetProviderCount(Connection connection,String proCode,String proName);

    //添加供应商
    public boolean AddProvider(Connection connection,SmbmsProvider provider);

    //查看供应商编码是否存在
    public boolean ProviderCodeIsExist(Connection connection,String pcode);

    //根据Id查信息
    public SmbmsProvider GetProviderByID(Connection connection,int id);

    //修改供应商信息
    public boolean UpdateProvider(Connection connection,SmbmsProvider provider);

    //删除供应商信息
    public boolean DeleteProvider(Connection connection,int id);

    //查询供应商是否有没付款订单
    public int ProviderIsNoPayment(Connection connection,int id);
}
