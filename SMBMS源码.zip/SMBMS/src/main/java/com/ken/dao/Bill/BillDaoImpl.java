package com.ken.dao.Bill;

import com.ken.dao.BaseDao;
import com.ken.pojo.SmbmsBill;
import com.mysql.cj.util.StringUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BillDaoImpl implements BillDao {
    //获取商品信息列表
    @Override
    public List<SmbmsBill> GetBillList(Connection connection ,String productName, int proid, int isPayment,int currentPageNo, int pageSize) {
        ArrayList<SmbmsBill> billArrayList = new ArrayList<>();

        if(connection!=null){
            StringBuffer sql = new StringBuffer();
            sql.append("SELECT b.*,p.proName FROM smbms_bill b ,smbms_provider  p where b.providerId = p.id ");

            ArrayList<Object> values = new ArrayList<>();

            if(!StringUtils.isNullOrEmpty(productName)){
                sql.append(" and productName like ? ");
                values.add("%" + productName + "%");
            }
            if( proid > 0){
                sql.append(" and P.id = ? ");
                values.add(proid);
            }
            if(isPayment>0){
                sql.append(" and isPayment = ? ");
                values.add(isPayment);
            }

            sql.append(" order by creationDate DESC limit ?,? ");
            currentPageNo = (currentPageNo-1)*pageSize;
            values.add(currentPageNo);
            values.add(pageSize);

            Object valueTemp[] = values.toArray();
            ResultSet resultSet=null;

            try {
                resultSet = BaseDao.ExecuteQuery(connection,sql.toString(),valueTemp);
                while (resultSet.next()){
                    SmbmsBill _smbmsBill = new SmbmsBill();
                    _smbmsBill.setbillCode(resultSet.getString("billCode"));
                    _smbmsBill.setproductName(resultSet.getString("productName"));
                    _smbmsBill.setproviderName(resultSet.getString("proName"));
                    _smbmsBill.settotalPrice((resultSet.getDouble("totalPrice")));
                    _smbmsBill.setisPayment(resultSet.getInt("ispayment"));
                    _smbmsBill.setcreationDate(resultSet.getDate("creationDate"));
                    _smbmsBill.setId(resultSet.getLong("id"));
                    billArrayList.add(_smbmsBill);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return billArrayList;
    }

    //商品总数
    @Override
    public int GetBillCount(Connection connection, String productName, int proid, int isPayment) {
        int count=0;
        if (connection != null) {
            StringBuffer sql = new StringBuffer();
            sql.append("SELECT count(b.id) as count FROM smbms_bill b ,smbms_provider  p where b.providerId = p.id ");

            ArrayList<Object> values = new ArrayList<>();

            if(!StringUtils.isNullOrEmpty(productName)){
                sql.append(" and productName like ? ");
                values.add("%" + productName + "%");
            }
            if(proid>0){
                sql.append(" and p.id = ? ");
                values.add(proid);
            }
            if(isPayment>0){
                sql.append(" and isPayment = ? ");
                values.add(isPayment);
            }

            Object valueTemp[] = values.toArray();
            ResultSet resultSet=null;

            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql.toString(), valueTemp);

                if (resultSet.next()) count=resultSet.getInt("count");

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return count;
    }

    //添加商品信息
    public boolean AddBill(Connection connection,SmbmsBill bill){
        int result = 0;
        if (connection!=null){
            String sql="insert into smbms_bill(billCode,productName,productDesc,productUnit," +
                    "productCount,totalPrice,providerId,isPayment,creationDate,createdBy)" +
                    " values(?,?,?,?,?,?,?,?,?,?)";

            Object values[] = {bill.getbillCode(),bill.getproductName(),bill.getproductDesc(),
                    bill.getproductUnit(),bill.getproductCount(),bill.gettotalPrice(),bill.getproviderId(),
                    bill.getisPayment(),bill.getcreationDate(),bill.getCreatedby()};

            try {
                result = BaseDao.ExecuteUpdate(connection, sql, values);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return result>0;
    }

    //订单编号是否存在
    @Override
    public boolean BillCodeIsExist(Connection connection, String billCode) {
        boolean flag = false;
        ResultSet resultSet = null;
        if (connection!=null){
            String sql = "select * from smbms_bill where billCode = ?";
            Object values[] = {billCode};

            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                flag = resultSet.next();
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }


        return flag;
    }

    //根据id查订单信息
    @Override
    public SmbmsBill GetBillByID(Connection connection, String ID) {
        SmbmsBill smbmsBill = null;
        ResultSet resultSet = null;

        if (connection!=null){
            String sql = "SELECT b.*,p.proName FROM smbms_lib.smbms_bill b, smbms_provider p where b.providerId = p.id and b.id = ?";
            Object values[] = {ID};

            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql, values);
                if (resultSet.next()) {
                    smbmsBill = new SmbmsBill();
                    smbmsBill.setId(Long.valueOf(resultSet.getInt("id")));
                    smbmsBill.setbillCode(resultSet.getString("billCode"));
                    smbmsBill.setproductName(resultSet.getString("productName"));
                    smbmsBill.setproductDesc(resultSet.getString("productDesc"));
                    smbmsBill.setproductUnit(resultSet.getString("productUnit"));
                    smbmsBill.setproductCount(Double.valueOf(resultSet.getString("productCount")));
                    smbmsBill.settotalPrice(resultSet.getDouble("totalPrice"));
                    smbmsBill.setproviderId(resultSet.getLong("providerId"));
                    smbmsBill.setisPayment(resultSet.getInt("isPayment"));
                    smbmsBill.setproviderName(resultSet.getString("proName"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return smbmsBill;
    }

    //修改订单信息
    @Override
    public boolean UpdateBill(Connection connection, SmbmsBill bill) {
        boolean flag = false;
        if (connection!=null){
            String sql = "update smbms_bill set billCode = ?,productName = ?,productDesc = ?, productUnit = ?," +
                    "productCount = ?,totalPrice = ?,providerId = ?,isPayment = ?,modifyBy = ?, modifyDate = ? where id = ?";
            Object values[]={bill.getbillCode(),bill.getproductName(),bill.getproductDesc(),bill.getproductUnit(),
                            bill.getproductCount(),bill.gettotalPrice(),bill.getproviderId(),bill.getisPayment(),bill.getModifyby(),bill.getModifydate(),bill.getId()};

            try {
                int i = BaseDao.ExecuteUpdate(connection, sql, values);
                flag = i>0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return flag;
    }


    //删除订单信息
    @Override
    public boolean DeleteBill(Connection connection, String id) {
        boolean flag = false;
        if (connection!=null){
            String sql = "delete from smbms_bill where id = ?";
            Object values[] = {id};
            int i = 0;
            try {
                i = BaseDao.ExecuteUpdate(connection, sql, values);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            flag = i>0;
        }
        return flag;
    }


}
