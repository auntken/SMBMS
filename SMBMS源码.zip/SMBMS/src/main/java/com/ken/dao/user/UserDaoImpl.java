package com.ken.dao.user;

import com.ken.dao.BaseDao;
import com.ken.pojo.SmbmsUser;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.util.StringUtils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao{
    @Override//用户登录验证
    public SmbmsUser GetLoginUser(Connection connection, String usercode) {
        String sql="select * from smbms_user where userCode=?";
        Object value[] = {usercode};
        ResultSet resultset= null;
        SmbmsUser smbmsUser = null;
        try {
            resultset = BaseDao.ExecuteQuery(connection,sql,value);
            if(resultset.next()){
                smbmsUser = new SmbmsUser();
                smbmsUser.setId(resultset.getInt("id"));
                smbmsUser.setuserCode(resultset.getString("userCode"));
                smbmsUser.setuserName(resultset.getString("userName"));
                smbmsUser.setUserpassword(resultset.getString("userPassword"));
                smbmsUser.setGender(resultset.getInt("gender"));
                smbmsUser.setBirthday(resultset.getDate("birthday"));
                smbmsUser.setPhone(resultset.getString("phone"));
                smbmsUser.setAddress(resultset.getString("address"));
                smbmsUser.setuserRole(resultset.getLong("userRole"));
                smbmsUser.setCreatedby(resultset.getLong("createdBy"));
                smbmsUser.setCreationdate(resultset.getDate("creationDate"));
                smbmsUser.setModifyby(resultset.getLong("modifyBy"));
                smbmsUser.setModifydate(resultset.getDate("modifyDate"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            BaseDao.CloseResource(connection,null,null);
        }
        return smbmsUser;
    }

    //用户修改密码
    @Override
    public boolean GetPasswordChangeResult(Connection connection,int id ,String password) {
        String sql = "update smbms_user set userPassword = ? where id = ?";
        Object value[] = {password,id};
        int executeNum = 0;
        if(connection!=null){
            try {
                executeNum = BaseDao.ExecuteUpdate(connection,sql,value);
                System.out.println("executeNum=" + executeNum);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return executeNum>0;
    }

    //根据用户名和权限查询用户数量
    @Override
    public int GetUserCount(Connection connection, String username, int userRole) {
        int count=0;

        if (connection!=null){
            StringBuffer sql = new StringBuffer();
            sql.append("select count(u.id) as count from smbms_user u ,smbms_role r where u.userRole = r.id ");
            ArrayList<Object> list = new ArrayList<>();

            if(!StringUtils.isNullOrEmpty(username)){
                sql.append(" u.userName like ? ");
                list.add("%" + username + "%");
            }
            if (userRole > 0){
                sql.append("and u.userRole = ?");
                list.add(userRole);
            }

            System.out.println(sql.toString());
            Object[] objects = list.toArray();
            ResultSet resultSet = null;
            try {
                resultSet  = BaseDao.ExecuteQuery(connection, sql.toString(), objects);
                System.out.println(resultSet.toString());
                if(resultSet.next()) count = resultSet.getInt("count");
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return count;
    }

    //获取用户列表
    @Override
    public List<SmbmsUser> GetUserList(Connection connection, String username, int userRole, int currentPageNo, int pageSize) {

        List<SmbmsUser> userList = new ArrayList<>();
        if(connection!=null){
            StringBuffer sql = new StringBuffer();
            sql.append("select u.*,r.roleName from smbms_user u,smbms_role r where u.userRole = r.id");
            ArrayList<Object> list = new ArrayList<>();

            if(!StringUtils.isNullOrEmpty(username)){
                sql.append(" and u.userName like ? ");
                list.add("%"+ username +"%");
            }
            if(userRole>0){
                sql.append(" and u.userRole = ?");
                list.add(userRole);
            }

            sql.append(" order by creationDate DESC limit ?,?");
            currentPageNo = (currentPageNo-1)*pageSize;
            list.add(currentPageNo);
            list.add(pageSize);

            Object[] values = list.toArray();
            ResultSet resultSet =null;
            try {
                resultSet = BaseDao.ExecuteQuery(connection, sql.toString(), values);
                while (resultSet.next()){
                    SmbmsUser _user = new SmbmsUser();
                    _user.setId(resultSet.getInt("id"));
                    _user.setuserCode(resultSet.getString("userCode"));
                    _user.setuserName(resultSet.getString("userName"));
                    _user.setGender(resultSet.getInt("gender"));
                    _user.setBirthday(resultSet.getDate("birthday"));
                    _user.setPhone(resultSet.getString("phone"));
                    _user.setuserRole(resultSet.getLong("userRole"));
                    _user.setuserRoleName(resultSet.getString("roleName"));
                    userList.add(_user);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }

        return userList;
    }

    //添加用户
    @Override
    public int AddUser(Connection connection, SmbmsUser user) {
        int result=0;
        if(connection!=null){
            String sql = "insert into smbms_user (userCode,userName,userPassword,gender,birthday,phone,address,userRole,createdBy,creationDate) " +
                    "values(?,?,?,?,?,?,?,?,?,?)";
            Object value[]={user.getuserCode(),user.getuserName(),user.getUserpassword(),user.getGender(),
                    user.getBirthday(),user.getPhone(),user.getAddress(),user.getuserRole(),user.getCreatedby(),
                    user.getCreationdate()};

            try {
                result = BaseDao.ExecuteUpdate(connection,sql,value);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    //根据id查用户信息
    @Override
    public SmbmsUser GetUserById(Connection connection, String id) {
        SmbmsUser smbmsUser=null;
        if(connection!=null){
            String sql = "SELECT u.*,r.roleName FROM smbms_user u ,smbms_role r where  u.userRole = r.id and  u.id = ?";
            Object values[] = {id};
            ResultSet resultSet = null;
            try {
                resultSet  = BaseDao.ExecuteQuery(connection, sql, values);
                if (resultSet.next()){
                    smbmsUser = new SmbmsUser();
                    smbmsUser.setuserCode(resultSet.getString("userCode"));
                    smbmsUser.setuserName(resultSet.getString("userName"));
                    smbmsUser.setGender(resultSet.getInt("gender"));
                    smbmsUser.setBirthday(resultSet.getDate("birthday"));
                    smbmsUser.setPhone(resultSet.getString("phone"));
                    smbmsUser.setAddress(resultSet.getString("address"));
                    smbmsUser.setuserRoleName(resultSet.getString("roleName"));
                    smbmsUser.setuserRole(resultSet.getLong("userRole"));
                    smbmsUser.setId(resultSet.getInt("id"));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }

        return smbmsUser;
    }

    //修改用户信息
    @Override
    public boolean UpdateUser(Connection connection, SmbmsUser user) {
        boolean flag=false;
        int result=0;
        if(connection!=null){
            String sql = "update smbms_user set userName = ?, gender = ?, birthday = ?, phone = ?, address = ?, userRole = ?," +
                    " creationDate = ?, createdBy = ? where id = ? ";
            Object values[] = {user.getuserName(),user.getGender(),user.getBirthday(),user.getPhone(),user.getAddress(),
                                user.getuserRole(),user.getCreationdate(),user.getCreatedby(),user.getId()};

            try {
                result = BaseDao.ExecuteUpdate(connection, sql, values);
                flag = result>0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return flag;
    }

    //删除用户信息
    @Override
    public boolean DelectUser(Connection connection, String id) {
        boolean flag=false;

        if(connection!=null){
            String sql = "delete from smbms_user where id = ? ";
            Object values[] = {id};

            try {
                int i = BaseDao.ExecuteUpdate(connection, sql, values);
                flag = i>0;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return flag;
    }


}
