package com.ken.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class BaseDao {
    private static String driver;
    private static String user;
    private static String password;
    private static String url;
    //静态代码块，加载db.properties为静态变量赋值
    static {
        InputStream is = BaseDao.class.getClassLoader().getResourceAsStream("db.properties");
        Properties properties = new Properties();
        try {
            properties.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
        driver = properties.getProperty("driver");
        user = properties.getProperty("user");
        password = properties.getProperty("password");
        url = properties.getProperty("url");
    }

    //获取数据库连接
    public static Connection GetConnection() throws ClassNotFoundException, SQLException {
        Class.forName(driver);

        return DriverManager.getConnection(url, user, password);
    }

    //查询
    public static ResultSet ExecuteQuery(Connection connection,String sql,Object[] value) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet=null;
        for (int i = 0; i < value.length; i++) {
            preparedStatement.setObject(i+1,value[i]);
        }
        resultSet = preparedStatement.executeQuery();
        return resultSet;
    }
    //增删改
    public static int ExecuteUpdate(Connection connection,String sql,Object[] value) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        for (int i = 0; i < value.length; i++) {
            preparedStatement.setObject(i+1,value[i]);
        }
        System.out.println(preparedStatement.toString());
        int result = preparedStatement.executeUpdate();
        return result;

    }

    //关闭资源
    public static Boolean CloseResource(Connection connection,PreparedStatement statement,ResultSet resultSet){
        boolean flag=true;
        if(resultSet!=null){
            try {
                resultSet.close();
                resultSet=null;
            } catch (SQLException e) {
                e.printStackTrace();
                flag=false;
            }
        }
        if(statement!=null){
            try {
                statement.close();
                statement=null;
            } catch (SQLException e) {
                e.printStackTrace();
                flag=false;
            }
        }
        if(connection!=null){
            try {
                connection.close();
                connection=null;
            } catch (SQLException e) {
                e.printStackTrace();
                flag=false;
            }
        }
        return flag;
    }


}
