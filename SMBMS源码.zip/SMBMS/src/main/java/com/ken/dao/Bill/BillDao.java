package com.ken.dao.Bill;

import com.ken.pojo.SmbmsBill;

import java.sql.Connection;
import java.util.List;

public interface BillDao {
    //获取商品信息列表
    public List<SmbmsBill> GetBillList(Connection connection ,String productName,  int proid, int isPayment,int currentPageNo, int pageSize);
    //商品总数
    public int GetBillCount(Connection connection ,String productName, int proid, int isPayment);

    //添加商品信息
    public boolean AddBill(Connection connection,SmbmsBill Bill);

    //核验订单编码是否存在
    public boolean BillCodeIsExist(Connection connection,String billCode);

    //根据id查订单信息
    public SmbmsBill GetBillByID(Connection connection,String ID);

    //修改订单信息
    public boolean UpdateBill(Connection connection, SmbmsBill smbmsBill);

    //删除订单信息
    public boolean DeleteBill(Connection connection, String id);
}
