package com.ken.dao.Role;

import com.ken.dao.BaseDao;
import com.ken.pojo.SmbmsRole;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoleDaoImpl implements RoleDao {
    @Override
    public List<SmbmsRole> GetRoleList(Connection connection) {
        ArrayList<SmbmsRole> RoleList =null;
        ResultSet resultSet =null;
        if(connection!=null){
            String sql = "SELECT * FROM smbms_lib.smbms_role";
            RoleList = new ArrayList<>();
            Object value[] = {};
            try {
                resultSet = BaseDao.ExecuteQuery(connection,sql,value);

                while(resultSet.next()){
                    SmbmsRole smbmsRole = new SmbmsRole();
                    smbmsRole.setId((long) resultSet.getInt("id"));
                    smbmsRole.setRolecode(resultSet.getString("roleCode"));
                    smbmsRole.setroleName(resultSet.getString("roleName"));
                    RoleList.add(smbmsRole);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }finally {
                BaseDao.CloseResource(null,null,resultSet);
            }
        }
        return RoleList;
    }

}
